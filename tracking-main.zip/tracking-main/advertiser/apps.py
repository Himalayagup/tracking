from django.apps import AppConfig


class AdvertiserConfig(AppConfig):
    name = 'advertiser'
