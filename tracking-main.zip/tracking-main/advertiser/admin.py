from django.contrib import admin
from advertiser.models import Advertiser
# Register your models here.
admin.site.register(Advertiser)
