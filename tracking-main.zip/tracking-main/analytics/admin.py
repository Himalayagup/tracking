from django.contrib import admin
from analytics.models import ObjectViewed, ObjectLead
# Register your models here.
admin.site.register(ObjectViewed)
admin.site.register(ObjectLead)
