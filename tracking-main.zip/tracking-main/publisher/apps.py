from django.apps import AppConfig


class PublisherConfig(AppConfig):
    name = 'publisher'
