from django.contrib import admin
from agency.models import Agency
# Register your models here.
admin.site.register(Agency)
